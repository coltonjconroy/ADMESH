%FIGSTATE    State of the figure
%   FIGSTATE(F) returns the state of the figure with handle F as
%   {Maximized | Minimized | Normal}
%
%   Example:
%   If
%       f = figure;
%       surf(peaks);
%   then
%       state = figstate(f)     returns the state = 'Normal'
% 
%   See also MAXFIG, MINFIG